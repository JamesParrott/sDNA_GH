#!/bin/sh

export PYTHONPATH=`pwd`
python3 tests/decoding_test.py
